package com.example.ta_ppb_niu_apps.listeners;

import com.example.ta_ppb_niu_apps.models.User;

public interface ConversionListener {
    void onConversionClicked(User user);
}
