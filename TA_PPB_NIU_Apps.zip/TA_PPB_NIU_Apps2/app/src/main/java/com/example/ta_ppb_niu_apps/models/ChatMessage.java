package com.example.ta_ppb_niu_apps.models;

import java.util.Date;

public class ChatMessage {
    public String senderId, receiverId, message, dateTime, receiverEmail, receiverInfo;
    public Date dateObject;
    public String conversionId, conversionName, conversionImage;
}
